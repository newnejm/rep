package com.yesserp.sessionbean.gs;

import javax.ejb.Local;

@Local
public interface GestionNotifLocal {

}
