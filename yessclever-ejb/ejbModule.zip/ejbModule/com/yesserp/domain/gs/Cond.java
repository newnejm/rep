package com.yesserp.domain.gs;

public class Cond {
	private boolean cond = true;
	public double qte;

	public boolean isCond() {
		return cond;
	}

	public void setCond(boolean cond) {
		this.cond = cond;
	}
}
